#!/usr/bin/env python3
import argparse, json, random, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BODIES=["sine_tri","pulse_swarm","additive","ring_body","parabolic_cluster"]
MODS=["none","fm","phase_warp","ring","cross_phase"]
NONLIN=["cubic","fold","softsign","asym_clip"]
NOISE=["none","white","sparse","dust"]
RATIOS=[1.25,1.3333333333,1.5,1.6,1.61803398875,1.6666666667,1.75,2.0,2.5,3.0,11/7,13/8]

def random_genome(seed=None):
    if seed is None:
        seed=random.SystemRandom().randrange(1,2**63)
    rng=random.Random(seed)
    return {
      "seed":seed, "generation":0, "parents":[],
      "body":rng.choice(BODIES),
      "modulation":rng.choice(MODS),
      "nonlinearity":rng.choice(NONLIN),
      "noise":rng.choice(NOISE),
      "ratio":rng.choice(RATIOS),
      "partials":rng.randint(3,9),
      "feedback":round(rng.uniform(0.0,0.34),5),
      "detune":round(rng.uniform(-0.008,0.008),6),
      "gain":round(rng.uniform(0.48,0.73),5),
    }

def load_genome(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def mutate_choice(rng, value, pool, rate=.22):
    return rng.choice(pool) if rng.random()<rate else value

def crossover(a,b,seed=None):
    if seed is None:
        seed=random.SystemRandom().randrange(1,2**63)
    rng=random.Random(seed)
    def pick(key): return a[key] if rng.random()<.5 else b[key]
    child={
      "seed":seed,
      "generation":max(int(a.get("generation",0)),int(b.get("generation",0)))+1,
      "parents":[a.get("name","parent-A"), b.get("name","parent-B")],
      "body":mutate_choice(rng,pick("body"),BODIES),
      "modulation":mutate_choice(rng,pick("modulation"),MODS),
      "nonlinearity":mutate_choice(rng,pick("nonlinearity"),NONLIN),
      "noise":mutate_choice(rng,pick("noise"),NOISE),
      "ratio":float(pick("ratio")),
      "partials":int(pick("partials")),
      "feedback":float(pick("feedback")),
      "detune":float(pick("detune")),
      "gain":float(pick("gain")),
    }
    if rng.random()<.28: child["ratio"]=rng.choice(RATIOS)
    if rng.random()<.32: child["partials"]=max(2,min(11,child["partials"]+rng.choice([-2,-1,1,2])))
    if rng.random()<.42: child["feedback"]=max(0.0,min(.38,child["feedback"]+rng.uniform(-.07,.07)))
    if rng.random()<.42: child["detune"]=max(-.01,min(.01,child["detune"]+rng.uniform(-.003,.003)))
    if rng.random()<.35: child["gain"]=max(.42,min(.78,child["gain"]+rng.uniform(-.07,.07)))
    child["feedback"]=round(child["feedback"],5)
    child["detune"]=round(child["detune"],6)
    child["gain"]=round(child["gain"],5)
    return child

def cpp_for(g):
    body_code={
      "sine_tri":"""
        float tr=1.f-4.f*fabsf((pa-floorf(pa))-0.5f);
        float x=(1.f-shape)*osc_sinf(pa)+shape*tr;
      """,
      "pulse_swarm":"""
        float a=(pa-floorf(pa))<(0.08f+0.84f*shift)?1.f:-1.f;
        float b=(pb-floorf(pb))<(0.82f-0.64f*shift)?1.f:-1.f;
        float c=((pa+pb*.37f)-floorf(pa+pb*.37f))<(0.30f+0.42f*shape)?1.f:-1.f;
        float x=(0.50f*a+0.32f*b+0.18f*c)*(0.70f+0.30f*shape);
      """,
      "additive":f"""
        float x=0.f;
        for(int h=1;h<={int(g["partials"])};++h){{
          x += osc_sinf(pa*(float)h+pb*0.07f*(float)(h-1))*(1.f/(float)h);
        }}
        x*=0.46f*(0.62f+0.38f*shape);
      """,
      "ring_body":"""
        float a=osc_sinf(pa), b=osc_sinf(pb);
        float x=(1.f-shape)*a+shape*(a*b);
      """,
      "parabolic_cluster":"""
        float q0=pa-floorf(pa);
        float q1=pb-floorf(pb);
        float p0=4.f*q0*(1.f-q0)-1.f;
        float p1=4.f*q1*(1.f-q1)-1.f;
        float x=(1.f-shape)*p0 + shape*(0.68f*p0+0.32f*p1);
      """
    }[g["body"]]

    mod_code={
      "none":"float modv=0.f;",
      "fm":"float modv=osc_sinf(pb)*p2*0.22f;",
      "phase_warp":"float modv=osc_sinf(pa*2.f+osc_sinf(pb)*p2)*p2*0.11f;",
      "ring":"float modv=(osc_sinf(pa)*osc_sinf(pb))*p2*0.13f;",
      "cross_phase":"float modv=osc_sinf(pb+prev*.12f)*p2*.16f;"
    }[g["modulation"]]

    nl_code={
      "cubic":"x=(1.f-p4*.58f)*x+(p4*.58f)*osc_sat_cubicf(clip1(x*(1.f+p4*3.2f)));",
      "fold":"""
        float d=clipn(x*(1.f+p4*5.f),4.f);
        for(int k=0;k<4 && (d>1.f||d<-1.f);++k){
          if(d>1.f)d=2.f-d;
          if(d<-1.f)d=-2.f-d;
        }
        x=(1.f-p4*.68f)*x+p4*.68f*d;
      """,
      "softsign":"x=x/(1.f+p4*2.8f*fabsf(x));",
      "asym_clip":"""
        float d=x*(1.f+p4*3.4f);
        if(d>1.f)d=1.f;
        if(d<-.55f-p4*.35f)d=-.55f-p4*.35f;
        x=(1.f-p4*.52f)*x+p4*.52f*d;
      """
    }[g["nonlinearity"]]

    noise_code={
      "none":"",
      "white":"x += osc_white()*p1*.23f;",
      "sparse":"if((osc_rand()&1023u)<(uint32_t)(2+p1*22.f))x+=osc_white()*(.18f+.62f*p1);",
      "dust":"if((osc_rand()&4095u)<(uint32_t)(1+p1*18.f))x+=(osc_rand()&1u?1.f:-1.f)*(.12f+.5f*p1);"
    }[g["noise"]]

    return f"""
#include "userosc.h"
#include <math.h>
#include <stdint.h>
static float pa=0.f,pb=0.f,prev=0.f;
static uint16_t P[8]={{25,35,40,35,20,40,512,512}};
static float mutant=0.f;
static inline float clip1(float x){{if(x>1.f)return 1.f;if(x<-1.f)return -1.f;return x;}}
static inline float clipn(float x,float n){{if(x>n)return n;if(x<-n)return -n;return x;}}

void OSC_INIT(uint32_t platform,uint32_t api){{(void)platform;(void)api;pa=pb=prev=0.f;mutant=0.f;}}
void OSC_NOTEON(const user_osc_param_t * const p){{(void)p;mutant=osc_white()*((float)P[5]/100.f);}}
void OSC_NOTEOFF(const user_osc_param_t * const p){{(void)p;}}
void OSC_PARAM(uint16_t i,uint16_t v){{if(i<8)P[i]=v;}}

void OSC_CYCLE(const user_osc_param_t * const params,int32_t *yn,const uint32_t frames){{
  uint8_t note=(uint8_t)(params->pitch>>8),fine=(uint8_t)(params->pitch&255);
  float w0=osc_w0f_for_note(note,fine);
  float p1=(float)P[0]/100.f,p2=(float)P[1]/100.f,p4=(float)P[3]/100.f,p5=(float)P[4]/100.f;
  float shape=(float)P[6]/1023.f;
  shape+=((float)params->shape_lfo/2147483648.f)*.45f;
  if(shape<0.f)shape=0.f;if(shape>1.f)shape=1.f;
  float shift=(float)P[7]/1023.f;
  for(uint32_t i=0;i<frames;++i){{
    {mod_code}
    pa += w0*(1.f+{float(g["detune"]):.9f}f+mutant*.008f)+modv*w0+prev*{float(g["feedback"]):.7f}f*w0;
    pb += w0*{float(g["ratio"]):.9f}f*(1.f+p5*.012f);
    pa-=floorf(pa);pb-=floorf(pb);
    {body_code}
    {noise_code}
    {nl_code}
    prev=clip1(x);
    yn[i]=f32_to_q31(clip1(x*{float(g["gain"]):.7f}f));
  }}
}}
"""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--seed",type=int)
    ap.add_argument("--parent-a")
    ap.add_argument("--parent-b")
    args=ap.parse_args()

    if args.parent_a and args.parent_b:
        a=load_genome(args.parent_a); b=load_genome(args.parent_b)
        g=crossover(a,b,args.seed)
    else:
        g=random_genome(args.seed)

    stamp=time.strftime("%Y%m%d_%H%M%S")
    name=f"G{int(g['generation']):03d}_{stamp}_{g['seed']&0xffff:04x}"
    g["name"]=name

    src=ROOT/"mutants"/f"{name}.cpp"
    so=ROOT/"build"/f"{name}.so"
    js=ROOT/"genomes"/f"{name}.json"
    src.write_text(cpp_for(g),encoding="utf-8")
    js.write_text(json.dumps(g,indent=2),encoding="utf-8")
    subprocess.run(["bash",str(ROOT/"build_host.sh"),str(src),str(so)],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
    print(json.dumps({"name":name,"so":str(so),"source":str(src),"genome":str(js),**g}))

if __name__=="__main__":
    main()
