#!/usr/bin/env python3
import ctypes,json,math,os,random,shutil,struct,subprocess,tempfile,wave
import tkinter as tk
from tkinter import filedialog,messagebox
import population

SR=48000; BLOCK=64
BG="#090a0c"; PANEL="#101216"; WHITE="#f3f3ef"; DIM="#8d9399"; LINE="#596067"; OLED_BG="#101916"; OLED="#b9f0cf"

class Params(ctypes.Structure):
    _fields_=[("shape_lfo",ctypes.c_int32),("pitch",ctypes.c_uint16),("cutoff",ctypes.c_uint16),
              ("resonance",ctypes.c_uint16),("reserved0",ctypes.c_uint16*3)]

class OscPlugin:
    def __init__(self,path):
        self.path=os.path.abspath(path); self.lib=ctypes.CDLL(self.path)
        self.init=self.lib._hook_init; self.cycle=self.lib._hook_cycle
        self.on=self.lib._hook_on; self.off=self.lib._hook_off; self.param=self.lib._hook_param
        self.init.argtypes=[ctypes.c_uint32,ctypes.c_uint32]
        self.cycle.argtypes=[ctypes.POINTER(Params),ctypes.POINTER(ctypes.c_int32),ctypes.c_uint32]
        self.on.argtypes=[ctypes.POINTER(Params)]; self.off.argtypes=[ctypes.POINTER(Params)]
        self.param.argtypes=[ctypes.c_uint16,ctypes.c_uint16]
        self.init(0,0x00010100)
    def set_param(self,i,v): self.param(i,int(v))

class Knob(tk.Canvas):
    def __init__(self,parent,label,var,lo,hi,command=None,size=82,fmt=None):
        super().__init__(parent,width=size,height=size+35,bg=parent["bg"],highlightthickness=0)
        self.var=var;self.lo=lo;self.hi=hi;self.command=command;self.size=size;self.label=label
        self.fmt=fmt or (lambda x:str(int(x)));self.last_y=None
        self.bind("<Button-1>",self.down);self.bind("<B1-Motion>",self.drag)
        self.bind("<MouseWheel>",self.wheel);self.bind("<Button-4>",lambda e:self.step(+1));self.bind("<Button-5>",lambda e:self.step(-1))
        var.trace_add("write",lambda *_:self.draw());self.draw()
    def down(self,e):self.last_y=e.y
    def drag(self,e):
        if self.last_y is None:return
        dy=self.last_y-e.y;self.last_y=e.y;self.set(self.var.get()+dy*(self.hi-self.lo)/180.0)
    def wheel(self,e):self.step(1 if e.delta>0 else -1)
    def step(self,d):self.set(self.var.get()+d*max(1,(self.hi-self.lo)/100))
    def set(self,v):
        v=max(self.lo,min(self.hi,v))
        if isinstance(self.var,tk.IntVar):v=int(round(v))
        self.var.set(v)
        if self.command:self.command()
    def draw(self):
        self.delete("all");s=self.size;cx=s/2;cy=s/2+5;r=s*.34
        self.create_text(cx,8,text=self.label,fill=WHITE,font=("DejaVu Sans",8,"bold"))
        self.create_oval(cx-r,cy-r,cx+r,cy+r,fill="#1a1c20",outline="#777d82",width=2)
        self.create_oval(cx-r*.72,cy-r*.72,cx+r*.72,cy+r*.72,fill="#111317",outline="#282c31")
        frac=(float(self.var.get())-self.lo)/(self.hi-self.lo) if self.hi!=self.lo else 0
        ang=math.radians(225-270*frac)
        self.create_line(cx,cy,cx+math.cos(ang)*r*.76,cy-math.sin(ang)*r*.76,fill=WHITE,width=3)
        for j in range(11):
            a=math.radians(225-270*j/10);a1=r*1.08;a2=r*1.18
            self.create_line(cx+math.cos(a)*a1,cy-math.sin(a)*a1,cx+math.cos(a)*a2,cy-math.sin(a)*a2,fill=DIM)
        self.create_text(cx,s+20,text=self.fmt(self.var.get()),fill=DIM,font=("DejaVu Sans",8))

def q31_to_i16(x):return max(-32768,min(32767,int(x)>>16))
def write_wav(path,q31):
    data=[q31_to_i16(x) for x in q31]
    if len(data)>512:
        n=min(int(.035*SR),len(data)//4)
        for i in range(n):
            g=i/n;data[i]=int(data[i]*g);data[-1-i]=int(data[-1-i]*g)
    with wave.open(path,"wb") as wf:
        wf.setnchannels(1);wf.setsampwidth(2);wf.setframerate(SR);wf.writeframes(struct.pack("<"+"h"*len(data),*data))
def play_file(path):
    for cmd in (["pw-play",path],["paplay",path],["aplay","-q",path],["ffplay","-nodisp","-autoexit","-loglevel","quiet",path]):
        if shutil.which(cmd[0]):
            subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);return cmd[0]

class Lab(tk.Tk):
    def __init__(self):
        super().__init__();self.title("LOGUE XD LAB v0.3 — Evolutionary User Oscillator Laboratory");self.configure(bg=BG)
        self.geometry("1240x820");self.minsize(1030,700)
        self.plugin=None;self.last_audio=[];self.current_genome=None;self.current_stress=None;self.lfo_phase=0.0
        self.db=population.PopulationDB(os.path.join(os.path.dirname(__file__) or '.', 'population.json'))
        self.so_path=tk.StringVar(value="build/random_morph.so");self.osc_name=tk.StringVar(value="RANDOM MORPH")
        self.note=tk.IntVar(value=48);self.fine=tk.IntVar(value=0);self.seconds=tk.DoubleVar(value=1.8)
        self.cutoff=tk.IntVar(value=8191);self.resonance=tk.IntVar(value=0)
        self.lfo_depth=tk.DoubleVar(value=0.0);self.lfo_rate=tk.DoubleVar(value=.7)
        self.values=[tk.IntVar(value=x) for x in (28,34,40,35,24,50,520,505)]
        self.names=["P1","P2","P3","P4","P5","P6","SHAPE","SHIFT SHAPE"]
        self.build_ui();self.refresh_population();self.after(180,self.autoload)

    def section(self,parent,title):
        f=tk.Frame(parent,bg=PANEL,highlightbackground=LINE,highlightthickness=1)
        tk.Label(f,text=title,bg=PANEL,fg=WHITE,font=("DejaVu Sans",8,"bold")).place(x=9,y=5);return f

    def build_ui(self):
        head=tk.Frame(self,bg=BG);head.pack(fill="x",padx=18,pady=(14,7))
        tk.Label(head,text="LOGUE XD LAB",bg=BG,fg=WHITE,font=("DejaVu Sans",20,"bold")).pack(side="left")
        tk.Label(head,text="EVOLUTIONARY USER OSCILLATOR LABORATORY  /  v0.3",bg=BG,fg=DIM,font=("DejaVu Sans",9)).pack(side="left",padx=16,pady=(8,0))
        tk.Label(head,text="48 kHz   Q31   CYCLE ≤ 64",bg=BG,fg=DIM,font=("DejaVu Sans Mono",8)).pack(side="right")

        face=tk.Frame(self,bg=PANEL,highlightbackground="#71767b",highlightthickness=1);face.pack(fill="x",padx=18)
        left=self.section(face,"HOST / PITCH");left.grid(row=0,column=0,sticky="nsew",padx=(7,4),pady=7)
        pr=tk.Frame(left,bg=PANEL);pr.pack(padx=8,pady=(25,8))
        Knob(pr,"NOTE",self.note,0,127).pack(side="left");Knob(pr,"FINE",self.fine,0,255).pack(side="left")
        Knob(pr,"LFO DEPTH",self.lfo_depth,0,1,fmt=lambda v:f"{v:.2f}").pack(side="left")
        Knob(pr,"LFO RATE",self.lfo_rate,.03,12,fmt=lambda v:f"{v:.2f}").pack(side="left")

        eng=self.section(face,"MULTI ENGINE / USR");eng.grid(row=0,column=1,sticky="nsew",padx=4,pady=7)
        oled=tk.Frame(eng,bg=OLED_BG,highlightbackground="#42544b",highlightthickness=1,width=260,height=70)
        oled.pack(padx=13,pady=(26,8));oled.pack_propagate(False)
        tk.Label(oled,textvariable=self.osc_name,bg=OLED_BG,fg=OLED,font=("DejaVu Sans Mono",12,"bold")).pack(pady=(12,0))
        self.genome_line=tk.StringVar(value="SOURCE HOST / SLOT —")
        tk.Label(oled,textvariable=self.genome_line,bg=OLED_BG,fg="#6e9a7e",font=("DejaVu Sans Mono",7)).pack()
        er=tk.Frame(eng,bg=PANEL);er.pack(padx=8,pady=(0,8))
        self.typevar=tk.IntVar(value=1)
        Knob(er,"TYPE",self.typevar,1,16,size=78).pack(side="left")
        Knob(er,"SHAPE",self.values[6],0,1023,command=lambda:self.push(6),size=78).pack(side="left")
        Knob(er,"SHIFT SHAPE",self.values[7],0,1023,command=lambda:self.push(7),size=78).pack(side="left")

        params=self.section(face,"USER OSCILLATOR PARAMETERS");params.grid(row=0,column=2,sticky="nsew",padx=(4,7),pady=7)
        prow=tk.Frame(params,bg=PANEL);prow.pack(padx=8,pady=(25,8))
        for i in range(6):Knob(prow,self.names[i],self.values[i],0,100,command=lambda j=i:self.push(j),size=72).pack(side="left")
        face.grid_columnconfigure(0,weight=1);face.grid_columnconfigure(1,weight=1);face.grid_columnconfigure(2,weight=2)

        bar=tk.Frame(self,bg=BG);bar.pack(fill="x",padx=18,pady=(10,4))
        for text,cmd in [("BUILD BASE",self.build_base),("LOAD .SO",self.choose_so),("▶ PLAY",self.play),
                         ("⚄ MUTATE PARAMS",self.mutate_params),("🧬 NEW ORGANISM",self.foundry),("SAVE WAV",self.save_wav)]:
            tk.Button(bar,text=text,command=cmd,bg="#171a1f",fg=WHITE,activebackground="#262b31",activeforeground=WHITE,
                      relief="flat",bd=0,padx=11,pady=8).pack(side="left",padx=(0,5))
        tk.Label(bar,textvariable=self.so_path,bg=BG,fg=DIM,font=("DejaVu Sans Mono",7)).pack(side="right")

        evo=tk.Frame(self,bg=BG);evo.pack(fill="x",padx=18,pady=(0,9))
        for text,cmd in [("TEST",self.run_stress),("♥ KEEP",self.keep_current),("× KILL",self.kill_current),
                         ("🧬 BREED KEPT",self.breed_kept),("PROMOTE TO XD",self.promote_current)]:
            tk.Button(evo,text=text,command=cmd,bg="#11151a",fg=WHITE,activebackground="#30363d",activeforeground=WHITE,
                      relief="flat",bd=0,padx=13,pady=7).pack(side="left",padx=(0,5))

        mid=tk.Frame(self,bg=BG);mid.pack(fill="both",expand=True,padx=18)
        scope=self.section(mid,"OSCILLOSCOPE / HOST RENDER");scope.pack(side="left",fill="both",expand=True,padx=(0,6))
        self.canvas=tk.Canvas(scope,bg="#07090b",height=225,highlightthickness=0);self.canvas.pack(fill="both",expand=True,padx=8,pady=(24,8))
        rt=self.section(mid,"RUNTIME INPUTS");rt.pack(side="right",fill="y",padx=(6,0))
        rr=tk.Frame(rt,bg=PANEL);rr.pack(padx=10,pady=(27,8))
        Knob(rr,"CUTOFF",self.cutoff,0,8191,size=77).grid(row=0,column=0)
        Knob(rr,"RESONANCE",self.resonance,0,8191,size=77).grid(row=0,column=1)
        Knob(rr,"PREVIEW s",self.seconds,.2,6,size=77,fmt=lambda v:f"{v:.1f}").grid(row=1,column=0)
        tk.Button(rr,text="LOW TEST",command=lambda:self.test_note(24),bg="#171a1f",fg=WHITE,relief="flat").grid(row=1,column=1,sticky="ew",padx=4,pady=7)
        tk.Button(rr,text="HIGH TEST",command=lambda:self.test_note(96),bg="#171a1f",fg=WHITE,relief="flat").grid(row=2,column=1,sticky="ew",padx=4)

        popsec=self.section(self,"POPULATION / LINEAGE")
        popsec.pack(fill="x",padx=18,pady=(10,5))
        self.population_text=tk.Text(popsec,height=5,bg="#080a0c",fg="#b9c1c8",insertbackground=WHITE,
                                    relief="flat",bd=0,font=("DejaVu Sans Mono",8))
        self.population_text.pack(fill="x",padx=8,pady=(24,8))
        self.population_text.configure(state="disabled")

        kb=self.section(self,"VIRTUAL KEYBOARD");kb.pack(fill="x",padx=18,pady=(5,5))
        keys=tk.Frame(kb,bg=PANEL);keys.pack(padx=9,pady=(24,8),fill="x")
        for n in range(36,61):
            black=(n%12) in (1,3,6,8,10)
            tk.Button(keys,text=str(n),command=lambda nn=n:self.key(nn),bg="#16181c" if black else "#deded8",
                      fg=WHITE if black else "#121212",activebackground="#3a3f46",relief="flat",bd=0,width=3,height=2).pack(side="left",expand=True,fill="x",padx=1)
        self.status=tk.StringVar(value="Ready.")
        tk.Label(self,textvariable=self.status,bg=BG,fg=DIM,anchor="w",font=("DejaVu Sans",8)).pack(fill="x",padx=20,pady=(2,10))

    def autoload(self):
        if os.path.exists(self.so_path.get()):self.load(self.so_path.get())
    def build_base(self):
        try:
            out=subprocess.check_output(["bash","build_host.sh"],cwd=os.path.dirname(__file__) or ".",text=True).strip()
            self.so_path.set(out);self.load(out);self.status.set("Base oscillator rebuilt.")
        except Exception as e:messagebox.showerror("Build failed",str(e))
    def choose_so(self):
        p=filedialog.askopenfilename(filetypes=[("Shared oscillator","*.so"),("All files","*")])
        if p:self.so_path.set(p);self.load(p)
    def load(self,path):
        try:
            self.plugin=OscPlugin(path)
            for i,v in enumerate(self.values):self.plugin.set_param(i,v.get())
            self.status.set("Loaded "+path)
        except Exception as e:messagebox.showerror("Load failed",str(e))
    def push(self,i):
        if self.plugin:
            try:self.plugin.set_param(i,self.values[i].get())
            except Exception:pass
    def mutate_params(self):
        for i in range(6):self.values[i].set(random.randint(0,100))
        self.values[6].set(random.randint(0,1023));self.values[7].set(random.randint(0,1023))
        for i in range(8):self.push(i)
        self.status.set("Parameter phenotype mutated.")
    def _current_record(self):
        if not self.current_genome:return None
        return self.db.get(self.current_genome.get("name"))

    def refresh_population(self):
        if not hasattr(self,"population_text"):return
        rows=self.db.last(10)
        lines=[]
        for r in rows:
            stress=r.get("stress") or {}
            score=stress.get("score","--")
            gen=r.get("generation",0)
            parents=r.get("parents") or []
            ptxt=(" <- "+",".join(parents)) if parents else ""
            lines.append(f"G{int(gen):03d}  {r.get('status','?'):<10}  score {str(score):>3}  {r.get('name','?')}{ptxt}")
        if not lines:lines=["No population yet. NEW ORGANISM creates the first founder."]
        self.population_text.configure(state="normal")
        self.population_text.delete("1.0","end")
        self.population_text.insert("1.0","\n".join(lines))
        self.population_text.configure(state="disabled")

    def foundry(self,parent_a=None,parent_b=None):
        try:
            cmd=["python3","foundry.py"]
            if parent_a and parent_b:
                cmd += ["--parent-a",parent_a,"--parent-b",parent_b]
            raw=subprocess.check_output(cmd,cwd=os.path.dirname(__file__) or ".",text=True)
            d=json.loads(raw.strip().splitlines()[-1]);self.current_genome=d
            self.so_path.set(d["so"]);self.osc_name.set(d["name"].upper())
            self.genome_line.set(f"G{d.get('generation',0):03d} {d['body']} / {d['modulation']} / {d['nonlinearity']} / {d['noise']}")
            self.load(d["so"])
            self.db.upsert({
                "name":d["name"],"generation":d.get("generation",0),"parents":d.get("parents",[]),
                "genome":d["genome"],"source":d["source"],"so":d["so"],"status":"candidate"
            })
            self.refresh_population()
            self.status.set("New oscillator compiled; running survival tests…")
            self.update_idletasks()
            self.run_stress(auto=True)
        except Exception as e:messagebox.showerror("Foundry failed",str(e))

    def run_stress(self,auto=False):
        if not self.so_path.get() or not os.path.exists(self.so_path.get()):
            if not auto:messagebox.showinfo("Stress test","Load or generate an oscillator first.")
            return
        try:
            proc=subprocess.run(["python3","stress_test.py",self.so_path.get()],
                                cwd=os.path.dirname(__file__) or ".",text=True,
                                capture_output=True,timeout=35)
            if proc.returncode!=0:
                raise RuntimeError(proc.stderr.strip() or f"stress process exited {proc.returncode}")
            d=json.loads(proc.stdout.strip().splitlines()[-1]);self.current_stress=d
            if self.current_genome:self.db.set_stress(self.current_genome["name"],d)
            flags=", ".join(d.get("flags",[])) or "clean"
            self.genome_line.set(f"STRESS {d.get('score',0):03d}/100  {flags}")
            self.status.set(("PASS" if d.get("pass") else "QUARANTINE")+f" · score {d.get('score')} · {flags}")
            self.refresh_population()
        except Exception as e:
            self.status.set("Stress test failed safely in subprocess: "+str(e))
            if not auto:messagebox.showerror("Stress test failed",str(e))

    def keep_current(self):
        if not self.current_genome:
            messagebox.showinfo("KEEP","Generate a Foundry organism first.");return
        self.db.set_status(self.current_genome["name"],"kept")
        self.status.set("♥ KEPT "+self.current_genome["name"])
        self.refresh_population()

    def kill_current(self):
        if not self.current_genome:
            messagebox.showinfo("KILL","Generate a Foundry organism first.");return
        self.db.set_status(self.current_genome["name"],"killed")
        self.status.set("× KILLED "+self.current_genome["name"]+" — source remains preserved for lineage.")
        self.refresh_population()

    def breed_kept(self):
        kept=self.db.kept()
        if len(kept)<2:
            messagebox.showinfo("BREED","KEEP at least two organisms first.");return
        a,b=kept[-2],kept[-1]
        self.status.set("Breeding "+a["name"]+" × "+b["name"])
        self.update_idletasks()
        self.foundry(a["genome"],b["genome"])

    def promote_current(self):
        if not self.current_genome:
            messagebox.showinfo("PROMOTE","Generate an organism first.");return
        rec=self.db.get(self.current_genome["name"]) or {}
        if rec.get("status")!="kept":
            ok=messagebox.askyesno("PROMOTE TO XD","This organism is not marked KEEP. Create a hardware promotion bundle anyway?")
            if not ok:return
        try:
            cmd=["python3","promote_xd.py","--name",self.current_genome["name"],
                 "--source",self.current_genome["source"],"--genome",self.current_genome["genome"]]
            sdk=os.environ.get("LOGUE_SDK")
            if sdk and os.path.isdir(sdk):cmd += ["--sdk",sdk]
            raw=subprocess.check_output(cmd,cwd=os.path.dirname(__file__) or ".",text=True)
            d=json.loads(raw.strip().splitlines()[-1])
            self.status.set("PROMOTED bundle: "+d["bundle"])
            extra=("\n\nInstalled into SDK:\n"+d["installed_sdk_project"]) if d.get("installed_sdk_project") else "\n\nRun INSTALL_INTO_LOGUE_SDK.sh inside that bundle when your official SDK checkout is ready."
            messagebox.showinfo("PROMOTE TO XD","Promotion bundle created:\n"+d["bundle"]+extra)
        except Exception as e:messagebox.showerror("Promotion failed",str(e))

    def render(self):
        if not self.plugin:self.autoload()
        if not self.plugin:return None
        p=Params();p.pitch=((self.note.get()&255)<<8)|(self.fine.get()&255);p.cutoff=self.cutoff.get();p.resonance=self.resonance.get();p.reserved0[:]=(0,0,0)
        total=int(self.seconds.get()*SR);out=[];self.plugin.on(ctypes.byref(p));done=0
        while done<total:
            n=min(BLOCK,total-done)
            lfo=math.sin(self.lfo_phase)*self.lfo_depth.get();p.shape_lfo=int(max(-.999,min(.999,lfo))*2147483647)
            self.lfo_phase+=2*math.pi*self.lfo_rate.get()*(n/SR)
            buf=(ctypes.c_int32*n)();self.plugin.cycle(ctypes.byref(p),buf,n);out.extend(int(buf[i]) for i in range(n));done+=n
        self.plugin.off(ctypes.byref(p));self.last_audio=out;self.draw_scope(out);return out
    def play(self):
        a=self.render()
        if not a:return
        p=os.path.join(tempfile.gettempdir(),"logue_xd_lab_v02.wav");write_wav(p,a);pl=play_file(p)
        self.status.set(("Playing via "+pl) if pl else ("Rendered "+p+"; no player found."))
    def save_wav(self):
        a=self.render()
        if not a:return
        p=filedialog.asksaveasfilename(defaultextension=".wav",filetypes=[("WAV","*.wav")],initialfile="xd_lab_render.wav")
        if p:write_wav(p,a);self.status.set("Saved "+p)
    def key(self,n):self.note.set(n);self.play()
    def test_note(self,n):
        old=self.note.get();self.note.set(n);self.play();self.note.set(old)
    def draw_scope(self,a):
        self.canvas.delete("all")
        if not a:return
        w=max(40,self.canvas.winfo_width());h=max(40,self.canvas.winfo_height());mid=h/2
        for x in range(0,w,50):self.canvas.create_line(x,0,x,h,fill="#151a1e")
        for y in range(0,h,40):self.canvas.create_line(0,y,w,y,fill="#151a1e")
        self.canvas.create_line(0,mid,w,mid,fill="#333b42")
        n=min(len(a),4096);step=max(1,n//w);pts=[];peak=0
        for x,idx in enumerate(range(0,n,step)):
            if x>=w:break
            v=a[idx]/2147483648.0;peak=max(peak,abs(v));pts += [x,mid-v*h*.43]
        if len(pts)>=4:self.canvas.create_line(*pts,fill="#d9ebe0",width=1.2)
        self.canvas.create_text(8,10,anchor="nw",fill=DIM,font=("DejaVu Sans Mono",8),text=f"NOTE {self.note.get():03d}  PEAK {peak:.3f}  BLOCK {BLOCK}")

if __name__=="__main__":Lab().mainloop()
