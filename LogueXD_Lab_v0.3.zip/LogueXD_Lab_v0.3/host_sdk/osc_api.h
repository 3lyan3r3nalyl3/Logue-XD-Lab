#pragma once
#include <stdint.h>
#include <math.h>

#define k_samplerate (48000)
#define k_samplerate_recipf (2.08333333333333e-5f)
#define k_note_mod_fscale (0.00392156862745098f)

static inline float osc_notehzf(uint8_t note) {
    return 440.0f * powf(2.0f, ((float)note - 69.0f) / 12.0f);
}

static inline float osc_w0f_for_note(uint8_t note, uint8_t mod) {
    const float f0 = osc_notehzf(note);
    const float f1 = osc_notehzf((uint8_t)(note + 1));
    const float hz = f0 + (f1 - f0) * ((float)mod * k_note_mod_fscale);
    return hz * k_samplerate_recipf;
}

static inline float osc_sinf(float phase) {
    phase -= floorf(phase);
    return sinf(phase * 6.2831853071795864769f);
}
static inline float osc_cosf(float phase) {
    phase -= floorf(phase);
    return cosf(phase * 6.2831853071795864769f);
}

static inline uint32_t osc_rand(void) {
    static uint32_t x = 0x6d2b79f5u;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return x;
}

static inline float osc_white(void) {
    const float u1 = ((osc_rand() & 0x00ffffffu) + 1.0f) / 16777217.0f;
    const float u2 = ((osc_rand() & 0x00ffffffu) + 1.0f) / 16777217.0f;
    const float z = sqrtf(-2.0f * logf(u1)) * cosf(6.2831853071795864769f * u2);
    float y = z * 0.32f;
    if (y > 1.f) y = 1.f;
    if (y < -1.f) y = -1.f;
    return y;
}

static inline float osc_sat_cubicf(float x) {
    if (x > 1.5f) x = 1.5f;
    if (x < -1.5f) x = -1.5f;
    return x - (x*x*x) / 3.0f;
}
