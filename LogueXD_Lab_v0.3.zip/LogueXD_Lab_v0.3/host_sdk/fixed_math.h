#pragma once
#include <stdint.h>

static inline int32_t f32_to_q31(float x) {
    if (x >= 1.0f) return 0x7fffffff;
    if (x <= -1.0f) return (int32_t)0x80000000u;
    return (int32_t)(x * 2147483647.0f);
}
static inline float q31_to_f32(int32_t x) {
    return (float)x / 2147483648.0f;
}
