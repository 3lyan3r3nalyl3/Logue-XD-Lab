# LOGUE XD LAB v0.3 — Evolutionary User Oscillator Laboratory

A Linux source-level virtual host, breeder and promotion laboratory for
**Korg minilogue xd logue-SDK v1.1-0 user oscillators**.

The central cycle is now:

`generate → compile → stress-test → audition → KEEP/KILL → BREED → lineage → PROMOTE TO XD`

## Selection enters the instrument

The black XD-adjacent panel now adds:

- **TEST**
- **♥ KEEP**
- **× KILL**
- **🧬 BREED KEPT**
- **PROMOTE TO XD**
- a live **POPULATION / LINEAGE** display

A generated oscillator is now a preserved individual with:

- genome
- generation number
- parents
- C++ phenotype
- host `.so`
- survival-test score
- selection status

## Breeding

KEEP two organisms and press **BREED KEPT**.

The child performs crossover between its parents and may mutate:

- waveform/body architecture
- modulation topology
- nonlinearity
- stochastic layer
- internal frequency ratio
- additive partial count
- feedback
- detuning
- output gain

## Automatic survival testing

Every newborn is tested in a separate Python subprocess.

The v0.3 suite checks seven notes and three parameter extremes for:

- silence / near-silence
- RMS level
- peak level
- DC offset
- clipping density
- full-scale hits
- a **host CPU proxy** measured as microseconds per 64-frame callback

The host timing number is not an ARM Cortex-M4 cycle budget; it is a comparative screening metric.

Failed organisms are marked **quarantine**, but they remain audible and can still be deliberately KEEPed.
Musical ugliness is not the same as technical failure.

## Hardware promotion

`PROMOTE TO XD` creates:

`promoted/<organism>/`

with:

- `userosc.cpp`
- `genome.json`
- `manifest.json`
- `project.mk`
- `INSTALL_INTO_LOGUE_SDK.sh`
- `PROMOTION.md`

The installer uses Korg's official `platform/minilogue-xd/dummy-osc` template.

Example:

```bash
cd promoted/G001_...
./INSTALL_INTO_LOGUE_SDK.sh ~/src/logue-sdk

cd ~/src/logue-sdk/platform/minilogue-xd/G001_...
make
make install
```

The official SDK build then creates the `.mnlgxdunit`.

You can also set:

```bash
export LOGUE_SDK=~/src/logue-sdk
```

before starting XD LAB; PROMOTE will install into that SDK checkout automatically when possible.

## Install / run

```bash
sudo apt update
sudo apt install build-essential python3 python3-tk

cd LogueXD_Lab_v0.3
chmod +x *.py build_host.sh
./build_host.sh
python3 xd_lab.py
```

## Main files

- `xd_lab.py` — black-panel virtual instrument
- `foundry.py` — genome generation, crossover and C++ emission
- `stress_test.py` — isolated survival laboratory
- `population.py` — persistent selection database
- `promote_xd.py` — official-template promotion bridge
- `host_sdk/` — source-level XD compatibility layer
- `mutants/` — generated C++ organisms
- `genomes/` — genetic records
- `promoted/` — hardware promotion bundles

## Scope boundary

This is still a **source-level compatibility host**, not an ARM Cortex-M4 instruction emulator.
The real minilogue xd remains the final authority for CPU budget, aliasing character and exact runtime behavior.

## v0.4 direction

- selectable parents rather than only the latest two KEEP organisms
- family-tree visualization
- favorites, notes and ratings
- spectral novelty and pitch-tracking analysis
- batch spawning ("spawn 12, audition survivors")
- hardware recording comparison
- optional direct ARM build when an official SDK checkout is configured
