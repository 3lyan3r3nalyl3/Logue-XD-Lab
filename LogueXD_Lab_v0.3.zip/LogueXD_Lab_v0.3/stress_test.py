#!/usr/bin/env python3
import argparse, ctypes, json, math, os, statistics, time
from pathlib import Path

SR=48000
BLOCK=64

class Params(ctypes.Structure):
    _fields_=[
      ("shape_lfo",ctypes.c_int32),
      ("pitch",ctypes.c_uint16),
      ("cutoff",ctypes.c_uint16),
      ("resonance",ctypes.c_uint16),
      ("reserved0",ctypes.c_uint16*3)
    ]

def load_plugin(path):
    lib=ctypes.CDLL(os.path.abspath(path))
    init=lib._hook_init; cycle=lib._hook_cycle
    on=lib._hook_on; off=lib._hook_off; param=lib._hook_param
    init.argtypes=[ctypes.c_uint32,ctypes.c_uint32]
    cycle.argtypes=[ctypes.POINTER(Params),ctypes.POINTER(ctypes.c_int32),ctypes.c_uint32]
    on.argtypes=[ctypes.POINTER(Params)]
    off.argtypes=[ctypes.POINTER(Params)]
    param.argtypes=[ctypes.c_uint16,ctypes.c_uint16]
    init(0,0x00010100)
    return cycle,on,off,param

def render(cycle,on,off,param,note,preset,seconds=.055):
    for i,v in enumerate(preset):
        param(i,int(v))
    p=Params()
    p.shape_lfo=0
    p.pitch=(note<<8)
    p.cutoff=8191
    p.resonance=0
    p.reserved0[:]=(0,0,0)
    total=int(seconds*SR)
    out=[]
    on(ctypes.byref(p))
    done=0
    while done<total:
        n=min(BLOCK,total-done)
        buf=(ctypes.c_int32*n)()
        cycle(ctypes.byref(p),buf,n)
        out.extend(int(buf[i]) for i in range(n))
        done+=n
    off(ctypes.byref(p))
    return [x/2147483648.0 for x in out]

def stats(x):
    if not x:
        return {"rms":0.0,"peak":0.0,"dc":0.0,"clip_fraction":0.0}
    peak=max(abs(v) for v in x)
    rms=math.sqrt(sum(v*v for v in x)/len(x))
    dc=sum(x)/len(x)
    clip=sum(1 for v in x if abs(v)>=.995)/len(x)
    return {"rms":rms,"peak":peak,"dc":dc,"clip_fraction":clip}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("so")
    ap.add_argument("--json-out")
    args=ap.parse_args()

    report={"file":os.path.abspath(args.so),"pass":True,"score":100,"flags":[],"tests":[]}
    try:
        cycle,on,off,param=load_plugin(args.so)
        notes=[24,36,48,60,72,84,96]
        presets=[
          [0,0,0,0,0,0,0,0],
          [50,50,50,50,50,50,512,512],
          [100,100,100,100,100,100,1023,1023],
        ]
        all_stats=[]
        for note in notes:
            for pi,preset in enumerate(presets):
                x=render(cycle,on,off,param,note,preset)
                s=stats(x)
                s.update({"note":note,"preset":pi})
                report["tests"].append(s)
                all_stats.append(s)

        max_peak=max(s["peak"] for s in all_stats)
        max_dc=max(abs(s["dc"]) for s in all_stats)
        max_clip=max(s["clip_fraction"] for s in all_stats)
        min_rms=min(s["rms"] for s in all_stats)
        med_rms=statistics.median(s["rms"] for s in all_stats)

        p=Params()
        p.pitch=60<<8; p.cutoff=8191; p.resonance=0; p.shape_lfo=0; p.reserved0[:]=(0,0,0)
        buf=(ctypes.c_int32*BLOCK)()
        for i in range(8):
            param(i,50 if i<6 else 512)
        on(ctypes.byref(p))
        rounds=3000
        t0=time.perf_counter()
        for _ in range(rounds):
            cycle(ctypes.byref(p),buf,BLOCK)
        elapsed=time.perf_counter()-t0
        off(ctypes.byref(p))
        us64=elapsed/rounds*1e6

        report["summary"]={
          "max_peak":max_peak,
          "max_abs_dc":max_dc,
          "max_clip_fraction":max_clip,
          "min_rms":min_rms,
          "median_rms":med_rms,
          "host_us_per_64":us64
        }

        if max_peak < .0005:
            report["flags"].append("silent"); report["score"]-=55
        if med_rms < .004:
            report["flags"].append("mostly_silent"); report["score"]-=25
        if max_dc > .20:
            report["flags"].append("large_dc"); report["score"]-=25
        elif max_dc > .08:
            report["flags"].append("dc_warning"); report["score"]-=10
        if max_clip > .30:
            report["flags"].append("heavy_clipping"); report["score"]-=25
        elif max_clip > .05:
            report["flags"].append("clipping"); report["score"]-=10
        if max_peak >= .999999:
            report["flags"].append("full_scale_hits"); report["score"]-=5
        if us64 > 1000:
            report["flags"].append("very_slow_host_proxy"); report["score"]-=20

        report["score"]=max(0,int(round(report["score"])))
        severe={"silent","mostly_silent","large_dc","heavy_clipping","very_slow_host_proxy"}
        report["pass"]=not any(f in severe for f in report["flags"])
    except Exception as e:
        report.update({"pass":False,"score":0,"flags":["host_exception"],"error":repr(e)})

    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report))

if __name__=="__main__":
    main()
