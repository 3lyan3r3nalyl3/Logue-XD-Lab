#!/usr/bin/env bash
set -euo pipefail
mkdir -p build
OSC="${1:-oscillators/random_morph.cpp}"
OUT="${2:-build/random_morph.so}"
g++ -std=c++17 -O2 -fPIC -shared -Ihost_sdk "$OSC" -o "$OUT" -lm
echo "$OUT"
