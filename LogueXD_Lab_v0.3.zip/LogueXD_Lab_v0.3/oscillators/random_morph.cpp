#include "userosc.h"
#include <math.h>
#include <stdint.h>

static float phase_a=0.f, phase_b=0.f, drift_phase=0.f;
static uint16_t p[8]={28,34,40,35,24,50,520,505};
static float mutation=0.f;

static inline float clamp1(float x){ if(x>1.f)return 1.f; if(x<-1.f)return -1.f; return x; }
static inline float tri(float ph){ ph-=floorf(ph); return 1.f-4.f*fabsf(ph-0.5f); }
static inline float pulse(float ph,float pw){ ph-=floorf(ph); return ph<pw?1.f:-1.f; }

void OSC_INIT(uint32_t platform,uint32_t api){
    (void)platform;(void)api; phase_a=phase_b=drift_phase=0.f; mutation=0.f;
}
void OSC_NOTEON(const user_osc_param_t * const params){
    (void)params; mutation=osc_white()*((float)p[5]*0.01f);
    phase_b=(osc_rand()&0xffffu)/65536.0f;
}
void OSC_NOTEOFF(const user_osc_param_t * const params){(void)params;}
void OSC_PARAM(uint16_t index,uint16_t value){ if(index<8)p[index]=value; }

void OSC_CYCLE(const user_osc_param_t * const params,int32_t *yn,const uint32_t frames){
    const uint8_t note=(uint8_t)(params->pitch>>8);
    const uint8_t fine=(uint8_t)(params->pitch&0xff);
    const float w0=osc_w0f_for_note(note,fine);
    float shape=(float)p[6]/1023.0f;
    shape += ((float)params->shape_lfo/2147483648.0f)*0.45f;
    if(shape<0.f)shape=0.f; if(shape>1.f)shape=1.f;
    const float shift=(float)p[7]/1023.0f;
    const float noise_amt=(float)p[0]/100.0f;
    const float fm_amt=(float)p[1]/100.0f;
    const float harmonics=1.f+7.f*((float)p[2]/100.0f);
    const float fold=(float)p[3]/100.0f;
    const float drift=(float)p[4]/100.0f;

    for(uint32_t i=0;i<frames;++i){
        drift_phase += 0.0000015f + drift*0.000015f;
        if(drift_phase>=1.f)drift_phase-=1.f;
        const float slow=osc_sinf(drift_phase)*drift*0.018f;
        const float mod=osc_sinf(phase_b)*fm_amt*(0.04f+0.18f*shape);
        phase_a += w0*(1.f+slow+mutation*0.012f)+mod*w0;
        phase_b += w0*(1.001f+0.031f*harmonics);
        phase_a-=floorf(phase_a); phase_b-=floorf(phase_b);
        const float s=osc_sinf(phase_a);
        const float t=tri(phase_a*(1.f+floorf(harmonics)));
        const float q=pulse(phase_b,0.08f+0.84f*shift);
        float body=(1.f-shape)*s+shape*(0.63f*t+0.37f*q);
        body=body*(1.f-0.34f*noise_amt)+osc_white()*noise_amt*0.34f;
        float driven=osc_sat_cubicf(body*(1.f+fold*4.2f));
        body=(1.f-fold*0.55f)*body+(fold*0.55f)*driven;
        yn[i]=f32_to_q31(clamp1(body*0.72f));
    }
}
