#!/usr/bin/env python3
import json, os, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent

class PopulationDB:
    def __init__(self, path=None):
        self.path = Path(path) if path else ROOT/"population.json"

    def _empty(self):
        return {"format": 1, "updated": None, "records": []}

    def load(self):
        if not self.path.exists():
            return self._empty()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or "records" not in data:
                return self._empty()
            return data
        except Exception:
            return self._empty()

    def save(self, data):
        data["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    def upsert(self, record):
        data = self.load()
        name = record["name"]
        old = next((r for r in data["records"] if r.get("name") == name), None)
        if old is None:
            rec = dict(record)
            rec.setdefault("status", "candidate")
            rec.setdefault("created", time.strftime("%Y-%m-%dT%H:%M:%S"))
            data["records"].append(rec)
        else:
            old.update(record)
        self.save(data)
        return self.get(name)

    def get(self, name):
        for r in self.load()["records"]:
            if r.get("name") == name:
                return r
        return None

    def set_status(self, name, status):
        data = self.load()
        for r in data["records"]:
            if r.get("name") == name:
                r["status"] = status
                r["status_time"] = time.strftime("%Y-%m-%dT%H:%M:%S")
                self.save(data)
                return r
        return None

    def set_stress(self, name, report):
        data = self.load()
        for r in data["records"]:
            if r.get("name") == name:
                r["stress"] = report
                if report.get("pass") is False and r.get("status") == "candidate":
                    r["status"] = "quarantine"
                self.save(data)
                return r
        return None

    def kept(self):
        return [r for r in self.load()["records"] if r.get("status") == "kept"]

    def last(self, n=12):
        return self.load()["records"][-n:]

if __name__ == "__main__":
    print(json.dumps(PopulationDB().load(), indent=2))
